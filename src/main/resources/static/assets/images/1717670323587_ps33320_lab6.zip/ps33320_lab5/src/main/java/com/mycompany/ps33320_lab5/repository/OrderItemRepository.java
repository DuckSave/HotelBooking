package com.mycompany.ps33320_lab5.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mycompany.ps33320_lab5.enity.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

}
