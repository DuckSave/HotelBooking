package com.mycompany.ps33320_lab5.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.mycompany.ps33320_lab5.enity.CartItem;
import com.mycompany.ps33320_lab5.enity.Order;
import com.mycompany.ps33320_lab5.enity.OrderItem;
import com.mycompany.ps33320_lab5.enity.Product;
import com.mycompany.ps33320_lab5.service.CartItemService;
import com.mycompany.ps33320_lab5.service.OrderItemService;
import com.mycompany.ps33320_lab5.service.OrderService;
import com.mycompany.ps33320_lab5.service.ProductService;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/cart")
public class CartController {
    @Autowired
    private CartItemService cartItemService;

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderItemService orderItemService;

    @GetMapping
    public String showCart(Model model) {
        List<CartItem> cartItems = cartItemService.listAll();
        double total = 0.0;
        for (CartItem item : cartItems) {
            total += item.getTotalPrice(); // Assuming getTotalPrice() method is implemented in CartItem
        }
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("total", total);
        return "cart";
    }

    @GetMapping("/add/{productId}")
    public String addToCart(@PathVariable("productId") Long productId) {
        Product product = productService.get(productId);
        if (product != null) {
            CartItem cartItem = new CartItem();
            cartItem.setProduct(product);
            cartItem.setQuantity(1); // Default quantity
            cartItemService.save(cartItem);
        }
        return "redirect:/cart";
    }

    @GetMapping("/delete/{id}")
    public String deleteCartItem(@PathVariable("id") Long id) {
        cartItemService.delete(id);
        return "redirect:/cart";
    }

    @GetMapping("/checkout")
    public String checkout() {
        List<CartItem> cartItems = cartItemService.listAll();
        if (!cartItems.isEmpty()) {
            Order order = new Order();
            order.setOrderDate(new Date());
            orderService.save(order);

            for (CartItem cartItem : cartItems) {
                OrderItem orderItem = new OrderItem();
                orderItem.setOrder(order);
                orderItem.setProduct(cartItem.getProduct());
                orderItem.setQuantity(cartItem.getQuantity());
                orderItem.setPrice(cartItem.getProduct().getPrice());
                orderItemService.save(orderItem);
            }

            cartItemService.deleteAll(); // Clear the cart
        }
        return "redirect:/products";
    }
}
