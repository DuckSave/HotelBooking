package com.mycompany.ps33320_lab5.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mycompany.ps33320_lab5.enity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

}
