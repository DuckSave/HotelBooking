package com.mycompany.ps33320_lab5.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.ps33320_lab5.enity.CartItem;
import com.mycompany.ps33320_lab5.repository.CartItemRepository;

@Service
public class CartItemService {
    @Autowired
    private CartItemRepository cartItemRepository;

    public List<CartItem> listAll() {
        return cartItemRepository.findAll();
    }

    public void save(CartItem cartItem) {
        cartItemRepository.save(cartItem);
    }

    public CartItem get(Long id) {
        return cartItemRepository.findById(id).orElse(null);
    }

    public void delete(Long id) {
        cartItemRepository.deleteById(id);
    }

    public void deleteAll() {
        cartItemRepository.deleteAllItems();
    }
}

