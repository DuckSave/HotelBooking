package com.mycompany.ps33320_lab5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps33320Lab5Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps33320Lab5Application.class, args);
	}

}
