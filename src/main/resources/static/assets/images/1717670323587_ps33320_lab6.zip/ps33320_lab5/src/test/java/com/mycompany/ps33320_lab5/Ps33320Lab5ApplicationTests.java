package com.mycompany.ps33320_lab5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps33320Lab5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
